import Cocoa

var str = "Actividad 3"
var numero1 = 10
var decimal  = 10.1
let pi:Float=3.141615
let texto:String = " string explicito"
var dato1:String=String()
var numero2:Int=Int()
var suma = numero1 + numero2
print(suma)
print("Variables: \(pi),\(texto)")
//Array
var numeros:Array<Int> = Array<Int>()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)
numeros.count

//Diccionario
var diasemana:Dictionary<String,Int> = Dictionary<String,Int>()
diasemana=["Domingo":1]
diasemana=["lunes":2]
diasemana=["martes":3]
diasemana=["miercoles ":4]
diasemana=["jueves":5]
diasemana=["viernes":6]
diasemana=["sabado":7]
print("Semana: \(diasemana.values)")

